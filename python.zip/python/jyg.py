num1=50
num2=20
num3=35
sum=num1+num2+num3
Avg=sum/3
print(Avg)
