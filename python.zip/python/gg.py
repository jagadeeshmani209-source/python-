a=int(input("num 1: "))
b=int(input("num 2: "))
c=int(input("num 3: "))
sum=num1+num2+num3
Avg=sum/3
print(Avg)
