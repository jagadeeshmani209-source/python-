a=10
b=3
print("add:",a+b)
print("sub:",a-b)
print("mul:",a*b)
print("divi:",a/b)
print("module:",a%b)
print("float:",a//b)
