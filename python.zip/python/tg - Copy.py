length=10
breath=20
Area=length*breath
print(Area)
