a=10
b=20
a,b=b,a
print("after swaping")
print("A=",a)
print("B=",b)
