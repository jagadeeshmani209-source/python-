print("Hi")
print(5)
print("Enter num:5")

